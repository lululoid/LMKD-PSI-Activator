#!/system/bin/sh
MODULEDIR=/data/adb/modules/fmiop-cleaner
swap=$NVBASE/fmiop_swap

rm -rf $swap
touch $MODULEDIR/remove
