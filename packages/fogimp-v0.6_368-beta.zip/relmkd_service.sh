#!/system/bin/sh
# shellcheck disable=SC3043,SC2034,SC2086,SC3060,SC3010

. $MODPATH/boot_config.sh

kill -9 $(resetprop fogimp.relmkd_service.pid)

while true; do
	relmkd
	sleep 30m
done &

resetprop fogimp.relmkd_service.pid $!
